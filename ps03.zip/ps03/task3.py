from task2 import tree_by_neighbor_joining, get_sequences_from_fasta_file
import numpy as np
from Bio import Phylo

def small_parsimony(tree):
  # nucleotides = ['A', 'C', 'G', 'T']
  # for node in tree.get_nonterminals(order='postorder'):
  return tree

if __name__ == '__main__':
  sequences = get_sequences_from_fasta_file('./fasta-sequences/fasta2.txt')
  tree = tree_by_neighbor_joining(sequences, True, "ascii")
  small_parsimony(tree[0])