from test import test_seq_assembly

if __name__ == '__main__':
  test_seq_assembly()
  